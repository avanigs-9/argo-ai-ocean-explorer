import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useLoader, useThree } from "@react-three/fiber";
import * as THREE from "three";

/* =========================================================
   LOCAL EARTH TEXTURES
========================================================= */

const TEXTURES = {
  day: "/textures/earth/earth_atmos_2048.jpg",
  night: "/textures/earth/earth_lights_2048.png",
  clouds: "/textures/earth/earth_clouds_1024.png",
  normal: "/textures/earth/earth_normal_2048.jpg",
  specular: "/textures/earth/earth_specular_2048.jpg",
};

/* =========================================================
   LAT/LON → 3D POSITION
========================================================= */

function latLonToVector3(lat, lon, radius = 1.48) {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);

  return new THREE.Vector3(
    -radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

/* =========================================================
   EARTH
========================================================= */

function Earth() {
  const [
    dayMap,
    nightMap,
    cloudMap,
    normalMap,
    specularMap,
  ] = useLoader(THREE.TextureLoader, [
    TEXTURES.day,
    TEXTURES.night,
    TEXTURES.clouds,
    TEXTURES.normal,
    TEXTURES.specular,
  ]);

  const earthRef = useRef();

  /* Color textures */
  dayMap.colorSpace = THREE.SRGBColorSpace;
  nightMap.colorSpace = THREE.SRGBColorSpace;

  /* Data textures */
  cloudMap.colorSpace = THREE.NoColorSpace;
  normalMap.colorSpace = THREE.NoColorSpace;
  specularMap.colorSpace = THREE.NoColorSpace;

  const material = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        dayMap: {
          value: dayMap,
        },

        nightMap: {
          value: nightMap,
        },

        cloudMap: {
          value: cloudMap,
        },

        normalMap: {
          value: normalMap,
        },

        specularMap: {
          value: specularMap,
        },

        sunDirection: {
          value: new THREE.Vector3(
            4,
            2,
            6
          ).normalize(),
        },

        time: {
          value: 0,
        },
      },

      vertexShader: `
        varying vec2 vUv;
        varying vec3 vWorldNormal;
        varying vec3 vWorldPosition;

        void main() {

          vUv = uv;

          vec4 worldPosition =
            modelMatrix *
            vec4(position, 1.0);

          vWorldPosition =
            worldPosition.xyz;

          vWorldNormal =
            normalize(
              mat3(modelMatrix) *
              normal
            );

          gl_Position =
            projectionMatrix *
            viewMatrix *
            worldPosition;
        }
      `,

      fragmentShader: `
        uniform sampler2D dayMap;
        uniform sampler2D nightMap;
        uniform sampler2D cloudMap;
        uniform sampler2D normalMap;
        uniform sampler2D specularMap;

        uniform vec3 sunDirection;
        uniform float time;

        varying vec2 vUv;
        varying vec3 vWorldNormal;
        varying vec3 vWorldPosition;

        void main() {

          /* =========================================
             DIRECTIONS
          ========================================= */

          vec3 N =
            normalize(vWorldNormal);

          vec3 L =
            normalize(sunDirection);

          vec3 V =
            normalize(
              cameraPosition -
              vWorldPosition
            );

          /* =========================================
             DAY / NIGHT TERMINATOR
          ========================================= */

          float lightAmount =
            dot(N, L);

          float dayFactor =
            smoothstep(
              -0.16,
              0.16,
              lightAmount
            );

          /* =========================================
             EARTH DAY TEXTURE
          ========================================= */

          vec3 dayColor =
            texture2D(
              dayMap,
              vUv
            ).rgb;

          /* =========================================
             CITY LIGHTS
          ========================================= */

          vec3 cityLights =
            texture2D(
              nightMap,
              vUv
            ).rgb;

          vec3 nightColor =
            cityLights *
            vec3(
              1.0,
              0.62,
              0.28
            ) *
            1.65;

          /* =========================================
             CLOUD SHADOW
          ========================================= */

          vec2 movingCloudUV =
            vUv +
            vec2(
              time * 0.002,
              0.0
            );

          float cloudShadow =
            texture2D(
              cloudMap,
              movingCloudUV
            ).r;

          float cloudDarkening =
            1.0 -
            cloudShadow *
            0.14 *
            dayFactor;

          /* =========================================
             DAY + NIGHT COMBINATION
          ========================================= */

          vec3 color =
            dayColor *
            (
              0.32 +
              dayFactor * 0.9
            );

          color =
            mix(
              nightColor,
              color,
              dayFactor
            );

          color *= cloudDarkening;

          /* =========================================
             OCEAN SPECULAR
          ========================================= */

          float oceanMask =
            texture2D(
              specularMap,
              vUv
            ).r;

          vec3 reflectedLight =
            reflect(
              -L,
              N
            );

          float specular =
            pow(
              max(
                dot(
                  reflectedLight,
                  V
                ),
                0.0
              ),
              65.0
            );

          color +=
            specular *
            oceanMask *
            vec3(
              0.30,
              0.85,
              0.95
            ) *
            0.85;

          /* =========================================
             NORMAL DETAIL
          ========================================= */

          vec3 normalDetail =
            texture2D(
              normalMap,
              vUv
            ).rgb;

          float surfaceDetail =
            (
              normalDetail.r -
              0.5
            ) * 0.08;

          color +=
            surfaceDetail *
            vec3(
              0.04,
              0.12,
              0.13
            );

          /* =========================================
             FINAL
          ========================================= */

          gl_FragColor =
            vec4(
              color,
              1.0
            );
        }
      `,
    });
  }, [
    dayMap,
    nightMap,
    cloudMap,
    normalMap,
    specularMap,
  ]);

  useFrame((_, delta) => {
    if (!earthRef.current) {
      return;
    }

    earthRef.current.rotation.y +=
      delta * 0.085;

    material.uniforms.time.value +=
      delta;
  });

  return (
    <mesh
      ref={earthRef}
    >
      <sphereGeometry
        args={[
          1.48,
          96,
          96,
        ]}
      />

      <primitive
        object={material}
        attach="material"
      />
    </mesh>
  );
}

/* =========================================================
   CLOUD LAYER
========================================================= */

function Clouds() {
  const cloudMap =
    useLoader(
      THREE.TextureLoader,
      TEXTURES.clouds
    );

  const cloudsRef =
    useRef();

  cloudMap.colorSpace =
    THREE.NoColorSpace;

  useFrame((_, delta) => {
    if (!cloudsRef.current) {
      return;
    }

    cloudsRef.current.rotation.y -=
      delta * 0.12;
  });

  return (
    <mesh
      ref={cloudsRef}
    >
      <sphereGeometry
        args={[
          1.515,
          72,
          72,
        ]}
      />

      <meshBasicMaterial
        map={cloudMap}
        transparent
        opacity={0.22}
        depthWrite={false}
        blending={
          THREE.AdditiveBlending
        }
      />
    </mesh>
  );
}

/* =========================================================
   ATMOSPHERE / FRESNEL GLOW
========================================================= */

function Atmosphere() {
  const material =
    useMemo(() => {
      return new THREE.ShaderMaterial({
        transparent: true,

        side:
          THREE.BackSide,

        blending:
          THREE.AdditiveBlending,

        depthWrite: false,

        uniforms: {
          glowColor: {
            value:
              new THREE.Color(
                "#39e6c4"
              ),
          },
        },

        vertexShader: `
          varying vec3 vNormal;
          varying vec3 vWorldPosition;

          void main() {

            vNormal =
              normalize(
                mat3(modelMatrix) *
                normal
              );

            vec4 worldPosition =
              modelMatrix *
              vec4(
                position,
                1.0
              );

            vWorldPosition =
              worldPosition.xyz;

            gl_Position =
              projectionMatrix *
              viewMatrix *
              worldPosition;
          }
        `,

        fragmentShader: `
          uniform vec3 glowColor;

          varying vec3 vNormal;
          varying vec3 vWorldPosition;

          void main() {

            vec3 N =
              normalize(
                vNormal
              );

            vec3 V =
              normalize(
                cameraPosition -
                vWorldPosition
              );

            float fresnel =
              pow(
                1.0 -
                max(
                  dot(N, V),
                  0.0
                ),
                3.0
              );

            float alpha =
              fresnel * 0.62;

            gl_FragColor =
              vec4(
                glowColor,
                alpha
              );
          }
        `,
      });
    }, []);

  return (
    <mesh
      scale={1.07}
    >
      <sphereGeometry
        args={[
          1.48,
          64,
          64,
        ]}
      />

      <primitive
        object={material}
        attach="material"
      />
    </mesh>
  );
}

/* =========================================================
   STARFIELD
========================================================= */

function StarField() {
  const starsRef =
    useRef();

  const positions =
    useMemo(() => {
      const array = [];

      for (
        let i = 0;
        i < 900;
        i++
      ) {
        const radius =
          7 +
          Math.random() * 7;

        const theta =
          Math.random() *
          Math.PI *
          2;

        const phi =
          Math.acos(
            2 *
              Math.random() -
              1
          );

        array.push(
          radius *
            Math.sin(phi) *
            Math.cos(theta),

          radius *
            Math.cos(phi),

          radius *
            Math.sin(phi) *
            Math.sin(theta)
        );
      }

      return new Float32Array(
        array
      );
    }, []);

  useFrame((_, delta) => {
    if (!starsRef.current) {
      return;
    }

    starsRef.current.rotation.y +=
      delta * 0.002;
  });

  return (
    <points
      ref={starsRef}
    >
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={
            positions.length / 3
          }
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>

      <pointsMaterial
        size={0.022}
        transparent
        opacity={0.7}
        sizeAttenuation
      />
    </points>
  );
}

/* =========================================================
   ARGO MARKER
========================================================= */

function ArgoMarker({
  position,
  index,
}) {
  const markerRef =
    useRef();

  const glowRef =
    useRef();

  useFrame(
    ({ clock }) => {
      const pulse =
        1 +
        Math.sin(
          clock.getElapsedTime() *
            2.4 +
            index
        ) *
          0.22;

      if (markerRef.current) {
        markerRef.current.scale.setScalar(
          pulse
        );
      }

      if (glowRef.current) {
        glowRef.current.scale.setScalar(
          pulse * 1.7
        );
      }
    }
  );

  return (
    <group
      position={position}
    >
      <mesh
        ref={markerRef}
      >
        <sphereGeometry
          args={[
            0.035,
            16,
            16,
          ]}
        />

        <meshBasicMaterial
          color="#ff6b5f"
        />
      </mesh>

      <mesh
        ref={glowRef}
      >
        <sphereGeometry
          args={[
            0.065,
            16,
            16,
          ]}
        />

        <meshBasicMaterial
          color="#ff6b5f"
          transparent
          opacity={0.20}
          blending={
            THREE.AdditiveBlending
          }
          depthWrite={false}
        />
      </mesh>
    </group>
  );
}

/* =========================================================
   ARGO MARKERS
========================================================= */

function ArgoMarkers() {
  const markerData =
    useMemo(
      () => [
        [18, 72],
        [8, 78],
        [-12, 45],
        [35, -40],
        [-25, -55],
        [2, 145],
        [42, 15],
        [-38, 110],
        [55, -150],
        [-5, -125],
      ],
      []
    );

  return (
    <>
      {markerData.map(
        ([lat, lon], index) => (
          <ArgoMarker
            key={index}
            position={latLonToVector3(
              lat,
              lon
            )}
            index={index}
          />
        )
      )}
    </>
  );
}

/* =========================================================
   CURVED ARGO CONNECTION
========================================================= */

function ArcLine({
  start,
  end,
}) {
  const geometry =
    useMemo(() => {
      const middle =
        start
          .clone()
          .add(end)
          .normalize()
          .multiplyScalar(
            1.70
          );

      const curve =
        new THREE.CatmullRomCurve3(
          [
            start,
            middle,
            end,
          ]
        );

      return new THREE.BufferGeometry().setFromPoints(
        curve.getPoints(35)
      );
    }, [start, end]);

  return (
    <line
      geometry={geometry}
    >
      <lineBasicMaterial
        color="#3ee0c0"
        transparent
        opacity={0.30}
      />
    </line>
  );
}

/* =========================================================
   ARGO CONNECTIONS
========================================================= */

function ArgoConnections() {
  const coordinates =
    useMemo(
      () => [
        [18, 72],
        [8, 78],
        [-12, 45],
        [35, -40],
        [-25, -55],
        [2, 145],
        [42, 15],
        [-38, 110],
        [55, -150],
        [-5, -125],
      ],
      []
    );

  const positions =
    coordinates.map(
      ([lat, lon]) =>
        latLonToVector3(
          lat,
          lon
        )
    );

  const connections = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 4],
    [5, 6],
    [6, 7],
    [8, 9],
  ];

  return (
    <>
      {connections.map(
        ([a, b], index) => (
          <ArcLine
            key={index}
            start={
              positions[a]
            }
            end={
              positions[b]
            }
          />
        )
      )}
    </>
  );
}

/* =========================================================
   EARTH GROUP
========================================================= */

function EarthScene({
  active,
}) {
  const groupRef =
    useRef();

  const { pointer } =
    useThree();

  useFrame((_, delta) => {
    if (
      !active ||
      !groupRef.current
    ) {
      return;
    }

    const targetX =
      -pointer.y * 0.055;

    const targetY =
      pointer.x * 0.075;

    groupRef.current.rotation.x =
      THREE.MathUtils.lerp(
        groupRef.current.rotation.x,
        targetX,
        1 -
          Math.pow(
            0.001,
            delta
          )
      );

    groupRef.current.rotation.y =
      THREE.MathUtils.lerp(
        groupRef.current.rotation.y,
        targetY,
        1 -
          Math.pow(
            0.001,
            delta
          )
      );
  });

  return (
    <group
  ref={groupRef}
  scale={0.78}
  rotation={[
    0,
    0,
    THREE.MathUtils.degToRad(
      21
    ),
  ]}
>
    
      <Earth />

      <Clouds />

      <Atmosphere />

      <ArgoMarkers />

      <ArgoConnections />
    </group>
  );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */

export default function RealisticEarth() {
  const containerRef =
    useRef();

  const [active, setActive] =
    useState(true);

  useEffect(() => {
    if (!containerRef.current) {
      return;
    }

    const observer =
      new IntersectionObserver(
        ([entry]) => {
          setActive(
            entry.isIntersecting
          );
        },
        {
          threshold: 0.1,
        }
      );

    observer.observe(
      containerRef.current
    );

    const handleVisibility =
      () => {
        setActive(
          document.visibilityState ===
            "visible"
        );
      };

    document.addEventListener(
      "visibilitychange",
      handleVisibility
    );

    return () => {
      observer.disconnect();

      document.removeEventListener(
        "visibilitychange",
        handleVisibility
      );
    };
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        position: "absolute",
        inset: "0",
        width: "100%",
        height: "100%",
        minHeight: "500px",
        zIndex: 5,
        pointerEvents: "auto",
      }}
    >
      <Canvas
        frameloop={
          active
            ? "always"
            : "never"
        }
        dpr={[1, 1.5]}
        camera={{
          position: [
            0,
            0,
            6.5,
          ],
          fov: 36,
        }}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference:
            "high-performance",
        }}
      >
        <Suspense
          fallback={null}
        >
          <StarField />

          <ambientLight
            intensity={0.12}
          />

          <EarthScene
            active={active}
          />
        </Suspense>
      </Canvas>
    </div>
  );
}
