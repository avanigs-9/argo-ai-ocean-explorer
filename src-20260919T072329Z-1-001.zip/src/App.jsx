import { useState } from "react";
import RealisticEarth from "./components/RealisticEarth";
import "./index.css";

const API_URL =
  import.meta.env.VITE_API_URL || "http://10.2.9.27:8001";

function Icon({ children, className = "" }) {
  return <span className={`icon ${className}`}>{children}</span>;
}

function App() {
  const questions = [
    "Show temperature near India",
    "Show salinity in Arabian Sea",
    "Where are the ARGO floats?",
    "Show temperature at 500 meters",
  ];

  const followUpQuestions = [
    "Show temperature trend",
    "Show salinity values",
    "Show deeper measurements",
  ];

  const [query, setQuery] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [darkMode, setDarkMode] = useState(true);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedFloat, setSelectedFloat] = useState(null);
  const [conversation, setConversation] = useState([]);

  const [response, setResponse] = useState({
    title: "AI Response",
    text:
      "Ask a question about ARGO ocean observations. The system will understand your query and retrieve matching data.",
  });

  const [oceanData, setOceanData] = useState({
    parameter: "—",
    value: "—",
    temperature: "—",
    salinity: "—",
    pressure: "—",
    depth: "—",
    observations: "—",
    dateRange: "—",
    floatId: "—",
    latitude: "—",
    longitude: "—",
    location: "—",
    dataSource: "Waiting for query",
    live: false,
  });

  const [chartData, setChartData] = useState([]);

  const [mapLocation, setMapLocation] = useState({
    latitude: null,
    longitude: null,
    location: "",
  });

  /* =========================================================
     CREATE STRUCTURED QUERY
     ========================================================= */

  const createStructuredQuery = async (question) => {
    const lowerQuestion = question.toLowerCase();

    /* =======================================================
       PARAMETER
       ======================================================= */

    let parameter = "temperature";

    if (lowerQuestion.includes("salinity")) {
      parameter = "salinity";
    } else if (lowerQuestion.includes("pressure")) {
      parameter = "pressure";
    } else if (
      lowerQuestion.includes("depth") ||
      lowerQuestion.includes("deeper")
    ) {
      parameter = "pressure";
    }

    /* =======================================================
       REGION
       IMPORTANT:
       Never use the entire globe as default.
       ======================================================= */

    // Default region = India / surrounding Indian Ocean
    let region = {
      lat_min: 0,
      lat_max: 30,
      lon_min: 40,
      lon_max: 100,
    };

    // India
    if (
      lowerQuestion.includes("india") ||
      lowerQuestion.includes("near india")
    ) {
      region = {
        lat_min: 5,
        lat_max: 25,
        lon_min: 65,
        lon_max: 90,
      };
    }

    // Arabian Sea
    if (lowerQuestion.includes("arabian sea")) {
      region = {
        lat_min: 5,
        lat_max: 25,
        lon_min: 50,
        lon_max: 75,
      };
    }

    // Bay of Bengal
    else if (
      lowerQuestion.includes("bay of bengal") ||
      lowerQuestion.includes("bay bengal")
    ) {
      region = {
        lat_min: 5,
        lat_max: 25,
        lon_min: 80,
        lon_max: 100,
      };
    }

    // Indian Ocean
    else if (
      lowerQuestion.includes("indian ocean") ||
      lowerQuestion.includes("indian ocean region")
    ) {
      region = {
        lat_min: -40,
        lat_max: 30,
        lon_min: 20,
        lon_max: 120,
      };
    }

    /* =======================================================
       DEPTH
       ======================================================= */

    let depth = {
      min: 0,
      max: 2000,
    };

    const depthMatch = lowerQuestion.match(
      /(\d+)\s*(?:meters|metres|meter|metre|m)\b/
    );

    if (depthMatch) {
      const value = Number(depthMatch[1]);

      depth = {
        min: Math.max(0, value - 50),
        max: value + 50,
      };
    }

    if (lowerQuestion.includes("500 meter")) {
      depth = {
        min: 450,
        max: 550,
      };
    }

    if (lowerQuestion.includes("1000 meter")) {
      depth = {
        min: 950,
        max: 1050,
      };
    }

    /* =======================================================
       DATE
       PROJECT DATA WINDOW = AUGUST 2026 ONLY
       ======================================================= */

    const start_date = "2026-08-01";
    const end_date = "2026-08-31";

    return {
      parameter,
      region,
      depth,
      start_date,
      end_date,
    };
  };

  /* =========================================================
     MAIN ARGO QUERY
     ========================================================= */

  const runQuery = async (question) => {
    const cleanQuestion = question.trim();

    setError("");

    if (!cleanQuestion) {
      setError("Please enter an ocean-data question first.");
      return;
    }

    setQuery(cleanQuestion);
    setActiveQuery(cleanQuestion);
    setLoading(true);
    setDetailsOpen(false);
    setSelectedFloat(null);

    setConversation((previous) => [
      ...previous.slice(-2),
      cleanQuestion,
    ]);

    try {
      /* =====================================================
         CREATE STRUCTURED QUERY
         ===================================================== */

      const aiResult =
        await createStructuredQuery(cleanQuestion);

      console.log(
        "AI STRUCTURED QUERY:",
        aiResult
      );

      /* =====================================================
         CALL FASTAPI BACKEND
         ===================================================== */

      const apiResponse = await fetch(
        `${API_URL}/api/argo/query`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            parameter: aiResult.parameter,
            region: aiResult.region,
            depth: aiResult.depth,
            start_date: aiResult.start_date,
            end_date: aiResult.end_date,
          }),
        }
      );

      if (!apiResponse.ok) {
        throw new Error(
          `Backend returned ${apiResponse.status}`
        );
      }

      const data = await apiResponse.json();

      console.log(
        "LIVE ARGO RESPONSE:",
        data
      );

      /* =====================================================
         AI RESPONSE
         ===================================================== */

      setResponse({
        title:
          data.title ||
          data.query?.parameter ||
          aiResult.parameter ||
          "ARGO Ocean Observation",

        text:
          data.summary ||
          data.text ||
          "Live ARGO data was retrieved for your query.",
      });

      /* =====================================================
         RESULT
         ===================================================== */

      const result =
        data.result ||
        data.data?.[0] ||
        data.data ||
        {};

      /* =====================================================
         OCEAN DATA
         ===================================================== */

      setOceanData({
        parameter:
          data.query?.parameter ||
          result.parameter ||
          aiResult.parameter ||
          "—",

        value:
          result.value ??
          result.temperature ??
          result.salinity ??
          result.pressure ??
          "—",

        temperature:
          result.temperature != null
            ? `${result.temperature} °C`
            : "—",

        salinity:
          result.salinity != null
            ? `${result.salinity} PSU`
            : "—",

        pressure:
          result.pressure != null
            ? `${result.pressure} dbar`
            : "—",

        depth:
          result.depth != null
            ? `${result.depth} m`
            : "—",

        observations:
          data.observations ??
          data.total_observations ??
          data.statistics?.valid_observations ??
          "—",

        dateRange:
          data.date_range ||
          result.date_range ||
          `${aiResult.start_date} → ${aiResult.end_date}`,

        floatId:
          result.float_id ||
          result.platform_number ||
          "—",

        latitude:
          result.latitude != null
            ? `${Number(result.latitude).toFixed(4)}°`
            : "—",

        longitude:
          result.longitude != null
            ? `${Number(result.longitude).toFixed(4)}°`
            : "—",

        location:
          data.query?.location ||
          result.location ||
          "ARGO observation region",

        dataSource:
          data.data_source ||
          data.source ||
          "ARGO",

        live:
          data.live !== false,
      });

      /* =====================================================
         CHART DATA
         ===================================================== */

      const incomingChart =
        data.chart ||
        data.chart_data ||
        result.chart ||
        [];

      if (Array.isArray(incomingChart)) {
        setChartData(incomingChart);
      } else {
        setChartData([]);
      }

      /* =====================================================
         MAP LOCATION
         ===================================================== */

      const latitude =
        result.latitude ??
        data.location?.latitude ??
        data.latitude;

      const longitude =
        result.longitude ??
        data.location?.longitude ??
        data.longitude;

      if (
        latitude !== undefined &&
        longitude !== undefined &&
        latitude !== null &&
        longitude !== null
      ) {
        setMapLocation({
          latitude: Number(latitude),
          longitude: Number(longitude),

          location:
            data.query?.location ||
            result.location ||
            "ARGO observation",
        });
      } else {
        setMapLocation({
          latitude: null,
          longitude: null,
          location: "",
        });
      }

      /* =====================================================
         SELECTED FLOAT
         ===================================================== */

      if (
        result.float_id ||
        result.platform_number
      ) {
        setSelectedFloat({
          id:
            result.float_id ||
            result.platform_number,

          location:
            result.location ||
            data.query?.location ||
            "ARGO region",

          latitude:
            result.latitude,

          longitude:
            result.longitude,

          temperature:
            result.temperature,

          salinity:
            result.salinity,

          depth:
            result.depth,

          pressure:
            result.pressure,

          date:
            result.date,

          status:
            result.status ||
            "Live",
        });
      }

    } catch (err) {
      console.error(
        "ARGO QUERY ERROR:",
        err
      );

      setError(
        "Unable to connect to the live ARGO data service. Make sure the FastAPI backend is running."
      );

      setResponse({
        title: "Connection Error",

        text:
          "The live ARGO service could not be reached. Start the FastAPI backend and try the query again.",
      });

      setChartData([]);

    } finally {
      setLoading(false);
    }
  };

  /* =========================================================
     SEARCH HANDLERS
     ========================================================= */

  const handleSubmit = (event) => {
    event.preventDefault();
    runQuery(query);
  };

  const handleQuestionClick = (question) => {
    setQuery(question);
    runQuery(question);
  };

  const handleFollowUp = (question) => {
    setQuery(question);
    runQuery(question);
  };

  /* =========================================================
     MAP
     ========================================================= */

  const focusMap = () => {
    const map =
      document.querySelector(
        ".map-container"
      );

    if (!map) return;

    map.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });

    map.classList.remove(
      "map-focus"
    );

    setTimeout(() => {
      map.classList.add(
        "map-focus"
      );

      setTimeout(() => {
        map.classList.remove(
          "map-focus"
        );
      }, 900);
    }, 400);
  };

  /* =========================================================
     DATA DETAILS
     ========================================================= */

  const toggleDataDetails = () => {
    setDetailsOpen(
      (previous) => !previous
    );
  };

  const clearSelectedFloat = () => {
    setSelectedFloat(null);
  };

  /* =========================================================
     PARAMETER BUTTONS
     ========================================================= */

  const handleParameterClick = (
    parameter
  ) => {
    if (parameter === "temperature") {
      runQuery(
        "Show temperature near India"
      );
      return;
    }

    if (parameter === "salinity") {
      runQuery(
        "Show salinity in Arabian Sea"
      );
      return;
    }

    if (
      parameter ===
      "pressure / depth"
    ) {
      runQuery(
        "Show deeper measurements"
      );
      return;
    }

    if (
      parameter ===
      "float locations"
    ) {
      runQuery(
        "Where are the ARGO floats?"
      );
    }
  };

  /* =========================================================
     CHART
     ========================================================= */

  const renderChart = () => {
    if (
      !chartData ||
      chartData.length === 0
    ) {
      return (
        <div className="chart-empty">
          No chart data returned for
          this query.
        </div>
      );
    }

    const width = 600;
    const height = 280;

    const padding = {
      top: 24,
      right: 30,
      bottom: 58,
      left: 72,
    };

    const plotWidth =
      width -
      padding.left -
      padding.right;

    const plotHeight =
      height -
      padding.top -
      padding.bottom;

    const points = chartData
      .map(
        (
          item,
          index
        ) => {
          const value =
            typeof item ===
            "number"
              ? Number(item)
              : Number(
                  item?.value
                );

          if (
            !Number.isFinite(
              value
            )
          ) {
            return null;
          }

          return {
            index,
            value,
          };
        }
      )
      .filter(Boolean);

    if (
      points.length === 0
    ) {
      return (
        <div className="chart-empty">
          The backend returned chart
          data, but no usable values
          were found.
        </div>
      );
    }

    const values =
      points.map(
        (point) =>
          point.value
      );

    let yMin =
      Math.min(
        ...values
      );

    let yMax =
      Math.max(
        ...values
      );

    if (
      yMin === yMax
    ) {
      const extra =
        Math.abs(
          yMin
        ) *
          0.1 ||
        1;

      yMin -= extra;
      yMax += extra;
    }

    const yPadding =
      (yMax - yMin) *
      0.08;

    yMin -= yPadding;
    yMax += yPadding;

    const yRange =
      yMax -
        yMin ||
      1;

    const xMin = 0;

    const xMax =
      Math.max(
        points.length - 1,
        1
      );

    const xRange =
      xMax -
      xMin;

    const getX = (
      index
    ) => {
      return (
        padding.left +
        (index / xRange) *
          plotWidth
      );
    };

    const getY = (
      value
    ) => {
      return (
        padding.top +
        plotHeight -
        ((value - yMin) /
          yRange) *
          plotHeight
      );
    };

    const linePoints =
      points
        .map(
          (point) =>
            `${getX(
              point.index
            )},${getY(
              point.value
            )}`
        )
        .join(" ");

    const yTickCount = 5;

    const yTicks =
      Array.from(
        {
          length:
            yTickCount,
        },
        (
          _,
          index
        ) => {
          const ratio =
            index /
            (yTickCount -
              1);

          const value =
            yMax -
            ratio *
              (yMax -
                yMin);

          return {
            value,
            y:
              padding.top +
              ratio *
                plotHeight,
          };
        }
      );

    const xTickCount =
      Math.min(
        6,
        Math.max(
          2,
          points.length
        )
      );

    const xTicks =
      Array.from(
        {
          length:
            xTickCount,
        },
        (
          _,
          index
        ) => {
          const ratio =
            index /
            (xTickCount -
              1);

          const pointIndex =
            Math.round(
              ratio *
                xMax
            );

          return {
            index:
              pointIndex,
            x:
              padding.left +
              ratio *
                plotWidth,
          };
        }
      );

    const parameterLabel =
      oceanData.parameter ===
      "salinity"
        ? "Salinity"
        : oceanData.parameter ===
          "pressure"
        ? "Pressure"
        : "Temperature";

    const unit =
      oceanData.parameter ===
      "salinity"
        ? "PSU"
        : oceanData.parameter ===
          "pressure"
        ? "dbar"
        : "°C";

    const formatYLabel =
      (value) => {
        if (
          Math.abs(
            value
          ) >= 100
        ) {
          return value.toFixed(
            0
          );
        }

        return value.toFixed(
          1
        );
      };

    return (
      <div className="chart-wrapper">
        <svg
          className="chart"
          viewBox={`0 0 ${width} ${height}`}
          role="img"
          aria-label={`${parameterLabel} chart`}
        >

          {yTicks.map(
            (
              tick,
              index
            ) => (
              <line
                key={`y-grid-${index}`}
                x1={
                  padding.left
                }
                y1={tick.y}
                x2={
                  width -
                  padding.right
                }
                y2={tick.y}
                className="chart-axis-grid"
              />
            )
          )}

          {xTicks.map(
            (
              tick,
              index
            ) => (
              <line
                key={`x-grid-${index}`}
                x1={tick.x}
                y1={
                  padding.top
                }
                x2={tick.x}
                y2={
                  height -
                  padding.bottom
                }
                className="chart-axis-grid"
              />
            )
          )}

          <line
            x1={
              padding.left
            }
            y1={
              padding.top
            }
            x2={
              padding.left
            }
            y2={
              height -
              padding.bottom
            }
            className="chart-axis"
          />

          <line
            x1={
              padding.left
            }
            y1={
              height -
              padding.bottom
            }
            x2={
              width -
              padding.right
            }
            y2={
              height -
              padding.bottom
            }
            className="chart-axis"
          />

          {yTicks.map(
            (
              tick,
              index
            ) => (
              <text
                key={`y-label-${index}`}
                x={
                  padding.left -
                  10
                }
                y={
                  tick.y + 4
                }
                textAnchor="end"
                className="chart-axis-text"
              >
                {formatYLabel(
                  tick.value
                )}
              </text>
            )
          )}

          {xTicks.map(
            (
              tick,
              index
            ) => (
              <text
                key={`x-label-${index}`}
                x={tick.x}
                y={
                  height -
                  padding.bottom +
                  22
                }
                textAnchor="middle"
                className="chart-axis-text"
              >
                {tick.index +
                  1}
              </text>
            )
          )}

          <text
            x="16"
            y={
              height / 2
            }
            textAnchor="middle"
            transform={`rotate(-90 16 ${
              height / 2
            })`}
            className="chart-axis-title"
          >
            {parameterLabel} ({unit})
          </text>

          <text
            x={
              padding.left +
              plotWidth / 2
            }
            y={
              height - 8
            }
            textAnchor="middle"
            className="chart-axis-title"
          >
            Observation Index
          </text>

          <polyline
            points={
              linePoints
            }
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="chart-line-green"
          />

          {points.map(
            (
              point,
              index
            ) => (
              <circle
                key={`point-${index}`}
                cx={getX(
                  point.index
                )}
                cy={getY(
                  point.value
                )}
                r="3"
                className="chart-point"
              >
                <title>
                  Observation{" "}
                  {point.index +
                    1}
                  :{" "}
                  {point.value}{" "}
                  {unit}
                </title>
              </circle>
            )
          )}
        </svg>
      </div>
    );
  };

  return (
    <div
      className={`app ${
        darkMode
          ? "dark-mode"
          : "light-mode"
      }`}
    >

      {/* =====================================================
          NAVBAR
          ===================================================== */}

      <header className="navbar">
        <div className="nav-inner">

          <div className="brand">
            <div className="brand-logo">
              🌊
            </div>

            <div className="brand-copy">
              <div className="brand-name">
                ARGO{" "}
                <span>
                  AI
                </span>
              </div>

              <div className="brand-tagline">
                Conversational Interface
                for Exploring Ocean Data
              </div>
            </div>
          </div>

          <nav className="nav-links">
            <a
              className="active"
              href="#home"
            >
              Home
            </a>

            <a href="#about">
              About
            </a>

            <a href="#features">
              Features
            </a>

            <a href="#data">
              Data
            </a>
          </nav>

          <button
            className="theme-button"
            aria-label="Change theme"
            onClick={() =>
              setDarkMode(
                (previous) =>
                  !previous
              )
            }
          >
            {darkMode
              ? "☼"
              : "☾"}
          </button>
        </div>
      </header>

      <main>

        {/* ===================================================
            HERO
            =================================================== */}

        <section
          className="hero"
          id="home"
        >
          <div className="hero-background-grid" />

          <div className="hero-inner">

            <div className="hero-content">

              <div className="eyebrow">
                <span className="status-dot" />

                LIVE ARGO DATA

                <span>
                  •
                </span>

                AI POWERED

                <span>
                  •
                </span>

                INTERACTIVE
                VISUALIZATIONS
              </div>

              <h1>
                Explore the Ocean
                <br />
                with{" "}
                <span>
                  AI
                </span>
              </h1>

              <p className="hero-description">
                Ask questions about
                ARGO ocean observations
                and get live,
                data-driven answers
                with charts, maps and
                precise measurements.
              </p>

              <div className="search-area">

                <form
                  className="search-box"
                  onSubmit={
                    handleSubmit
                  }
                >

                  <span className="search-icon">
                    ⌕
                  </span>

                  <input
                    type="text"
                    value={query}
                    onChange={(
                      event
                    ) =>
                      setQuery(
                        event.target
                          .value
                      )
                    }
                    placeholder='Try asking... "Show temperature in Arabian Sea at 500 meters during August 2026"'
                    aria-label="Ask about ARGO ocean data"
                  />

                  <button
                    type="submit"
                    disabled={
                      loading
                    }
                  >
                    {loading ? (
                      <span className="button-loader" />
                    ) : (
                      "Ask →"
                    )}
                  </button>
                </form>

                {error && (
                  <div className="search-error">
                    ⚠{" "}
                    {error}
                  </div>
                )}

                <div className="popular">

                  <span className="popular-label">
                    Popular questions:
                  </span>

                  <div className="question-list">

                    {questions.map(
                      (
                        question
                      ) => (
                        <button
                          key={
                            question
                          }
                          type="button"
                          onClick={() =>
                            handleQuestionClick(
                              question
                            )
                          }
                        >
                          {
                            question
                          }
                        </button>
                      )
                    )}

                  </div>
                </div>
              </div>
            </div>

            {/* =================================================
                3D EARTH
                ================================================= */}

            <div className="hero-visual">

              <div className="orbit orbit-one" />
              <div className="orbit orbit-two" />
              <div className="glow" />

              <RealisticEarth />

              <div className="floating-dot dot-one" />
              <div className="floating-dot dot-two" />
              <div className="floating-dot dot-three" />
              <div className="floating-dot dot-four" />

              <div className="stats-card">

                <div className="stat">

                  <div className="stat-heading">
                    <span className="green-dot" />
                    ARGO FLOATS
                  </div>

                  <strong>
                    LIVE
                  </strong>

                  <small>
                    Global observations
                  </small>
                </div>

                <div className="stat-divider" />

                <div className="stat">

                  <div className="stat-heading">
                    <span className="coral-dot" />
                    MATCHED DATA
                  </div>

                  <strong>
                    {
                      oceanData.observations
                    }
                  </strong>

                  <small>
                    Measurements
                  </small>
                </div>

              </div>

              <div className="visual-caption">

                <span />

                <div>
                  LIVE GLOBAL OCEAN

                  <strong>
                    INTELLIGENCE
                  </strong>
                </div>

              </div>
            </div>
          </div>
        </section>

        {/* ===================================================
            DASHBOARD
            =================================================== */}

        <section
          className="dashboard"
          id="features"
        >

          <div className="dashboard-inner">

            {/* =================================================
                AI RESPONSE
                ================================================= */}

            <div className="ai-response">

              <div className="ai-icon">
                🤖
              </div>

              <div className="ai-copy">

                <div className="response-title-row">

                  <h2>
                    {loading
                      ? "Analyzing live ARGO data..."
                      : response.title}
                  </h2>

                  {!loading &&
                    activeQuery && (
                      <span className="response-status">
                        ●{" "}
                        {oceanData.live
                          ? "Live"
                          : "Demo"}
                      </span>
                    )}
                </div>

                <p>
                  {loading
                    ? "Understanding your query, matching location/depth/date and retrieving ocean observations..."
                    : response.text}
                </p>

                {activeQuery &&
                  !loading && (
                    <small className="active-query">
                      Current query:
                      "
                      {
                        activeQuery
                      }
                      "
                    </small>
                  )}
              </div>

              {loading ? (
                <div className="ai-loading">
                  <span />
                  <span />
                  <span />
                </div>
              ) : (
                <div className="wave">
                  ∿∿∿
                </div>
              )}
            </div>

            {/* =================================================
                CONVERSATION
                ================================================= */}

            {conversation.length >
              0 && (
              <div className="conversation-panel">

                <div className="conversation-heading">

                  <span>
                    💬
                  </span>

                  <div>
                    <strong>
                      Conversation
                      context
                    </strong>

                    <small>
                      Your recent
                      ocean
                      questions
                    </small>
                  </div>
                </div>

                <div className="conversation-list">

                  {conversation.map(
                    (
                      item,
                      index
                    ) => (
                      <button
                        key={`${item}-${index}`}
                        type="button"
                        onClick={() =>
                          runQuery(
                            item
                          )
                        }
                      >
                        {
                          item
                        }
                      </button>
                    )
                  )}

                </div>

                <div className="follow-up">

                  <span>
                    Continue
                    exploring:
                  </span>

                  <div>

                    {followUpQuestions.map(
                      (
                        question
                      ) => (
                        <button
                          key={
                            question
                          }
                          type="button"
                          onClick={() =>
                            handleFollowUp(
                              question
                            )
                          }
                        >
                          {
                            question
                          }{" "}
                          →
                        </button>
                      )
                    )}

                  </div>
                </div>
              </div>
            )}

            {/* =================================================
                CARDS
                ================================================= */}

            <div className="cards-grid">

              {/* ===============================================
                  OCEAN DATA
                  =============================================== */}

              <article
                className="data-card"
                id="data"
              >

                <div className="card-header">

                  <div className="card-icon coral-icon">
                    ▥
                  </div>

                  <div>
                    <h2>
                      Ocean Data
                    </h2>

                    <p>
                      Live matched
                      ARGO
                      observations
                    </p>
                  </div>

                </div>

                <div className="chart-container">

                  <div className="chart-grid" />

                  {renderChart()}

                  <div className="chart-legend">

                    <div>

                      <span className="legend-green" />

                      {oceanData.parameter ||
                        "Parameter"}

                      <strong>
                        {
                          oceanData.value
                        }
                      </strong>

                    </div>

                    <div>

                      <span className="legend-coral" />

                      Depth

                      <strong>
                        {
                          oceanData.depth
                        }
                      </strong>

                    </div>

                    <div>

                      <span className="legend-purple" />

                      Source

                      <strong>
                        {
                          oceanData.dataSource
                        }
                      </strong>

                    </div>

                  </div>
                </div>

                <div className="observation-stats">

                  <div>
                    <span>
                      OBSERVATIONS
                    </span>

                    <strong>
                      {
                        oceanData.observations
                      }
                    </strong>
                  </div>

                  <div>
                    <span>
                      DATE RANGE
                    </span>

                    <strong>
                      {
                        oceanData.dateRange
                      }
                    </strong>
                  </div>

                </div>

                <button
                  className="card-action"
                  type="button"
                  onClick={
                    toggleDataDetails
                  }
                >
                  {detailsOpen
                    ? "Hide Data Details ↑"
                    : "View Data Details →"}
                </button>

                {detailsOpen && (
                  <div className="data-details">

                    {[
                      [
                        "Parameter",
                        oceanData.parameter,
                      ],
                      [
                        "Value",
                        oceanData.value,
                      ],
                      [
                        "Temperature",
                        oceanData.temperature,
                      ],
                      [
                        "Salinity",
                        oceanData.salinity,
                      ],
                      [
                        "Pressure",
                        oceanData.pressure,
                      ],
                      [
                        "Depth",
                        oceanData.depth,
                      ],
                      [
                        "Float ID",
                        oceanData.floatId,
                      ],
                      [
                        "Latitude",
                        oceanData.latitude,
                      ],
                      [
                        "Longitude",
                        oceanData.longitude,
                      ],
                      [
                        "Location",
                        oceanData.location,
                      ],
                      [
                        "Data source",
                        oceanData.dataSource,
                      ],
                    ].map(
                      ([
                        label,
                        value,
                      ]) => (
                        <div
                          className="detail-row"
                          key={
                            label
                          }
                        >

                          <span>
                            {
                              label
                            }
                          </span>

                          <strong>
                            {
                              value
                            }
                          </strong>

                        </div>
                      )
                    )}

                  </div>
                )}

              </article>

              {/* ===============================================
                  MAP
                  =============================================== */}

              <article className="data-card">

                <div className="card-header">

                  <div className="card-icon green-icon">
                    ✧
                  </div>

                  <div>

                    <h2>
                      ARGO Observation
                      Location
                    </h2>

                    <p>
                      Live location
                      matched to
                      your query
                    </p>

                  </div>

                </div>

                <div className="map-container">

                  <div className="map-grid" />

                  <div className="map-earth">
                    🌍
                  </div>

                  {mapLocation.latitude !==
                    null &&
                    mapLocation.longitude !==
                      null && (

                      <button
                        type="button"
                        className="map-point p1 selected"
                        style={{
                          left: "50%",
                          top: "50%",
                        }}
                        title={`${mapLocation.location} — ${mapLocation.latitude}, ${mapLocation.longitude}`}
                        onClick={
                          focusMap
                        }
                      />

                    )}

                  <div className="map-location-label">

                    {mapLocation.latitude !==
                    null ? (

                      <>

                        <strong>
                          {
                            mapLocation.location ||
                            "Matched location"
                          }
                        </strong>

                        <span>
                          {
                            mapLocation.latitude
                          }
                          °,{" "}
                          {
                            mapLocation.longitude
                          }
                          °
                        </span>

                      </>

                    ) : (

                      <span>
                        Submit a
                        query to
                        locate an
                        ARGO
                        observation
                      </span>

                    )}

                  </div>

                  <div className="map-legend">

                    <div>
                      <span className="green-dot" />
                      Live result
                    </div>

                    <div>
                      <span className="cyan-dot" />
                      ARGO
                      location
                    </div>

                  </div>

                </div>

                {selectedFloat && (

                  <div className="float-details">

                    <div className="float-details-top">

                      <div>

                        <span>
                          LIVE FLOAT
                        </span>

                        <strong>
                          {
                            selectedFloat.id
                          }
                        </strong>

                      </div>

                      <button
                        type="button"
                        aria-label="Close selected float"
                        onClick={
                          clearSelectedFloat
                        }
                      >
                        ×
                      </button>

                    </div>

                    <p>
                      📍{" "}
                      {
                        selectedFloat.location
                      }
                    </p>

                    <div className="float-grid">

                      <div>
                        <span>
                          POSITION
                        </span>

                        <strong>
                          {
                            selectedFloat.latitude
                          }
                          ,{" "}
                          {
                            selectedFloat.longitude
                          }
                        </strong>
                      </div>

                      <div>
                        <span>
                          STATUS
                        </span>

                        <strong>
                          {
                            selectedFloat.status
                          }
                        </strong>
                      </div>

                      <div>
                        <span>
                          TEMPERATURE
                        </span>

                        <strong>
                          {
                            selectedFloat.temperature ??
                            "—"
                          }
                        </strong>
                      </div>

                      <div>
                        <span>
                          SALINITY
                        </span>

                        <strong>
                          {
                            selectedFloat.salinity ??
                            "—"
                          }
                        </strong>
                      </div>

                    </div>

                    <div className="detail-row">

                      <span>
                        Depth
                      </span>

                      <strong>
                        {
                          selectedFloat.depth ??
                          "—"
                        }
                      </strong>

                    </div>

                    <div className="detail-row">

                      <span>
                        Observation
                        date
                      </span>

                      <strong>
                        {
                          selectedFloat.date ??
                          "—"
                        }
                      </strong>

                    </div>

                  </div>
                )}

                <button
                  className="card-action"
                  type="button"
                  onClick={
                    focusMap
                  }
                >
                  Explore Map →
                </button>

              </article>

              {/* ===============================================
                  PARAMETERS
                  =============================================== */}

              <article className="data-card parameters-card">

                <div className="card-header">

                  <div className="card-icon green-icon">
                    ≋
                  </div>

                  <div>

                    <h2>
                      Key Ocean
                      Parameters
                    </h2>

                    <p>
                      Ask
                      natural-language
                      questions
                    </p>

                  </div>

                </div>

                <div className="parameter-grid">

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "temperature"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ◉
                    </div>

                    <div>

                      <h3>
                        Temperature
                      </h3>

                      <p>
                        Ocean heat &
                        climate
                      </p>

                    </div>

                  </button>

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "salinity"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ◌
                    </div>

                    <div>

                      <h3>
                        Salinity
                      </h3>

                      <p>
                        Water
                        composition
                      </p>

                    </div>

                  </button>

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "pressure / depth"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ≋
                    </div>

                    <div>

                      <h3>
                        Pressure /
                        Depth
                      </h3>

                      <p>
                        Ocean
                        structure
                      </p>

                    </div>

                  </button>

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "float locations"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ✧
                    </div>

                    <div>

                      <h3>
                        Float ID
                      </h3>

                      <p>
                        Track ARGO
                        sensors
                      </p>

                    </div>

                  </button>

                </div>

                <button
                  className="card-action"
                  type="button"
                  onClick={() => {

                    document
                      .querySelector(
                        ".search-box input"
                      )
                      ?.focus();

                    document
                      .querySelector(
                        ".search-box"
                      )
                      ?.scrollIntoView({
                        behavior:
                          "smooth",
                        block:
                          "center",
                      });

                  }}
                >
                  Ask Another Question →
                </button>

              </article>

            </div>
          </div>
        </section>

        {/* ===================================================
            FOOTER
            =================================================== */}

        <footer id="about">

          <div className="footer-inner">

            <div className="footer-item">

              <div className="footer-icon">
                ◎
              </div>

              <div>

                <strong>
                  Global Coverage
                </strong>

                <span>
                  ARGO ocean
                  observations
                </span>

              </div>

            </div>

            <div className="footer-item">

              <div className="footer-icon">
                □
              </div>

              <div>

                <strong>
                  Open Data
                </strong>

                <span>
                  Live ocean
                  data access
                </span>

              </div>

            </div>

            <div className="footer-item">

              <div className="footer-icon coral-text">
                ϟ
              </div>

              <div>

                <strong>
                  AI Powered
                </strong>

                <span>
                  Natural language
                  queries
                </span>

              </div>

            </div>

            <div className="footer-message">

              Live data.

              <span>
                Better ocean intelligence.
              </span>

            </div>

          </div>
        </footer>

      </main>
    </div>
  );
}

export default App;