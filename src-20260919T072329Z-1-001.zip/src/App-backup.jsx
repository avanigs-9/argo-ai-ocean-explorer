import { useState } from "react";
import RealisticEarth from "./components/RealisticEarth";
import "./index.css";

function Icon({ children, className = "" }) {
  return <span className={`icon ${className}`}>{children}</span>;
}

function App() {
  // =========================================================
  // QUESTIONS
  // =========================================================

  const questions = [
    "Temperature near India",
    "Salinity in Arabian Sea",
    "Where are the floats?",
    "Show deeper measurements",
  ];

  const followUpQuestions = [
    "Show temperature trend",
    "Show salinity values",
    "Show deeper measurements",
  ];

  // =========================================================
  // MOCK FLOAT DATA
  // =========================================================

  const floats = [
    {
      id: "ARGO-2901",
      location: "Arabian Sea",
      latitude: "18.2° N",
      longitude: "72.4° E",
      status: "Active",
      lastObservation: "Today",
      temperature: "24.7°C",
      salinity: "35.2 PSU",
      depth: "10 m",
    },
    {
      id: "ARGO-1842",
      location: "Bay of Bengal",
      latitude: "13.1° N",
      longitude: "85.7° E",
      status: "Recent",
      lastObservation: "2 hours ago",
      temperature: "27.1°C",
      salinity: "34.8 PSU",
      depth: "15 m",
    },
    {
      id: "ARGO-3920",
      location: "Indian Ocean",
      latitude: "8.4° S",
      longitude: "72.8° E",
      status: "Active",
      lastObservation: "Today",
      temperature: "23.9°C",
      salinity: "35.5 PSU",
      depth: "20 m",
    },
    {
      id: "ARGO-1175",
      location: "Southern Indian Ocean",
      latitude: "25.2° S",
      longitude: "61.3° E",
      status: "Inactive",
      lastObservation: "4 days ago",
      temperature: "18.6°C",
      salinity: "34.9 PSU",
      depth: "100 m",
    },
    {
      id: "ARGO-4218",
      location: "Western Pacific",
      latitude: "2.8° N",
      longitude: "145.1° E",
      status: "Recent",
      lastObservation: "5 hours ago",
      temperature: "28.2°C",
      salinity: "34.4 PSU",
      depth: "10 m",
    },
  ];

  // =========================================================
  // CHART DATA
  // =========================================================

  const defaultChartData = {
    temperature: [
      190, 145, 180, 105, 150, 92, 135, 82, 130, 95, 125,
    ],
    salinity: [
      215, 200, 207, 165, 190, 155, 178, 145, 172, 150, 170,
    ],
  };

  // =========================================================
  // STATE
  // =========================================================

  const [query, setQuery] = useState("");

  const [activeQuery, setActiveQuery] = useState("");

  const [loading, setLoading] = useState(false);

  const [error, setError] = useState("");

  const [darkMode, setDarkMode] = useState(true);

  const [detailsOpen, setDetailsOpen] = useState(false);

  const [selectedFloat, setSelectedFloat] = useState(null);

  const [conversation, setConversation] = useState([]);

  const [chartData, setChartData] = useState(defaultChartData);

  const [oceanData, setOceanData] = useState({
    temperature: "24.7°C",
    salinity: "35.2 PSU",
    depth: "10 m",
    observations: "1,248",
    dateRange: "01 Sep – 18 Sep 2026",
  });

  const [response, setResponse] = useState({
    title: "AI Response",
    text:
      "Ask a question above to explore ARGO ocean observations. Your results will appear here.",
  });

  // =========================================================
  // QUERY HANDLER
  // =========================================================

  const runQuery = (question) => {
    const cleanQuestion = question.trim();

    setError("");

    if (!cleanQuestion) {
      setError("Please enter an ocean-data question first.");
      return;
    }

    setQuery(cleanQuestion);
    setActiveQuery(cleanQuestion);
    setLoading(true);
    setDetailsOpen(false);

    // Keep selected float only for direct float interaction.
    // Normal questions clear the previous selection.
    setSelectedFloat(null);

    // Add question to conversation context
    setConversation((previous) => [
      ...previous.slice(-2),
      cleanQuestion,
    ]);

    // Frontend demonstration delay
    setTimeout(() => {
      const lower = cleanQuestion.toLowerCase();

      // =====================================================
      // TEMPERATURE
      // =====================================================

      if (
        lower.includes("temperature") ||
        lower.includes("india") ||
        lower.includes("heat")
      ) {
        setResponse({
          title: "Temperature near India",
          text:
            "The demonstration ARGO observations show warm surface waters around the Indian Ocean, with a representative temperature of 24.7°C.",
        });

        setOceanData({
          temperature: "24.7°C",
          salinity: "35.2 PSU",
          depth: "10 m",
          observations: "1,248",
          dateRange: "01 Sep – 18 Sep 2026",
        });

        setChartData({
          temperature: [
            190, 175, 160, 145, 130, 112, 125, 98, 105, 82, 90,
          ],
          salinity: [
            215, 205, 210, 198, 190, 182, 188, 175, 180, 168, 172,
          ],
        });
      }

      // =====================================================
      // SALINITY
      // =====================================================

      else if (
        lower.includes("salinity") ||
        lower.includes("arabian")
      ) {
        setResponse({
          title: "Salinity in Arabian Sea",
          text:
            "The demonstration observations show salinity around 35.2–35.8 PSU across the selected Arabian Sea region.",
        });

        setOceanData({
          temperature: "26.1°C",
          salinity: "35.8 PSU",
          depth: "15 m",
          observations: "864",
          dateRange: "05 Sep – 18 Sep 2026",
        });

        setChartData({
          temperature: [
            205, 198, 185, 170, 178, 160, 148, 155, 138, 145, 128,
          ],
          salinity: [
            180, 155, 165, 140, 150, 125, 135, 112, 128, 105, 115,
          ],
        });
      }

      // =====================================================
      // FLOATS
      // =====================================================

      else if (
        lower.includes("float") ||
        lower.includes("where")
      ) {
        setResponse({
          title: "ARGO Float Locations",
          text:
            "The map below shows example ARGO float locations. Select a marker to inspect its latest observation.",
        });

        setOceanData({
          temperature: "25.3°C",
          salinity: "35.4 PSU",
          depth: "8 m",
          observations: "3,984",
          dateRange: "01 Sep – 18 Sep 2026",
        });

        setSelectedFloat(floats[0]);

        setChartData({
          temperature: [
            180, 155, 170, 135, 150, 118, 140, 105, 125, 98, 115,
          ],
          salinity: [
            205, 190, 200, 175, 185, 160, 178, 150, 170, 145, 160,
          ],
        });
      }

      // =====================================================
      // DEEPER DATA
      // =====================================================

      else if (
        lower.includes("deeper") ||
        lower.includes("depth") ||
        lower.includes("pressure")
      ) {
        setResponse({
          title: "Deeper Ocean Measurements",
          text:
            "The demonstration dataset is showing a deeper profile around 500 m, where temperature is lower than at the surface.",
        });

        setOceanData({
          temperature: "12.8°C",
          salinity: "35.0 PSU",
          depth: "500 m",
          observations: "642",
          dateRange: "03 Sep – 18 Sep 2026",
        });

        setChartData({
          temperature: [
            85, 100, 115, 128, 142, 155, 168, 182, 195, 208, 220,
          ],
          salinity: [
            145, 148, 150, 153, 155, 158, 160, 162, 165, 168, 170,
          ],
        });
      }

      // =====================================================
      // UNKNOWN QUERY
      // =====================================================

      else {
        setResponse({
          title: "Ocean Observation",
          text:
            "I couldn't match that question to one of the frontend demonstration datasets. Try asking about temperature, salinity, float locations, or depth.",
        });

        setOceanData({
          temperature: "24.7°C",
          salinity: "35.2 PSU",
          depth: "10 m",
          observations: "1,248",
          dateRange: "01 Sep – 18 Sep 2026",
        });

        setChartData(defaultChartData);
      }

      setLoading(false);
    }, 800);
  };

  // =========================================================
  // SEARCH SUBMIT
  // =========================================================

  const handleSubmit = (event) => {
    event.preventDefault();
    runQuery(query);
  };

  // =========================================================
  // QUESTION BUTTON
  // =========================================================

  const handleQuestionClick = (question) => {
    setQuery(question);
    runQuery(question);
  };

  // =========================================================
  // FOLLOW-UP QUESTION
  // =========================================================

  const handleFollowUp = (question) => {
    setQuery(question);
    runQuery(question);
  };

  // =========================================================
  // FLOAT SELECTION
  // =========================================================

  const handleFloatClick = (float) => {
    setSelectedFloat(float);
    setDetailsOpen(true);

    setActiveQuery(`Explore ${float.id}`);

    setConversation((previous) => [
      ...previous.slice(-2),
      `Explore ${float.id}`,
    ]);

    setResponse({
      title: `${float.id} — ${float.location}`,
      text: `Latest observation from this ${float.status.toLowerCase()} ARGO float. The selected float is currently showing ${float.temperature} temperature and ${float.salinity} salinity at ${float.depth}.`,
    });

    setOceanData({
      temperature: float.temperature,
      salinity: float.salinity,
      depth: float.depth,
      observations: "1,248",
      dateRange: "01 Sep – 18 Sep 2026",
    });

    // Give every selected float a slightly different
    // visualization so the interaction is visible.
    const index = floats.findIndex(
      (item) => item.id === float.id
    );

    const temperatureSets = [
      [190, 180, 170, 160, 150, 142, 135, 128, 120, 115, 110],
      [175, 165, 155, 145, 135, 128, 120, 112, 105, 100, 94],
      [200, 188, 175, 165, 152, 145, 135, 125, 118, 108, 100],
      [155, 150, 145, 138, 132, 125, 118, 110, 105, 98, 92],
      [210, 198, 188, 178, 168, 158, 148, 138, 128, 118, 108],
    ];

    const salinitySets = [
      [210, 205, 200, 195, 188, 182, 178, 174, 170, 168, 165],
      [190, 185, 180, 175, 170, 165, 160, 155, 150, 145, 140],
      [220, 212, 205, 198, 190, 185, 178, 172, 166, 160, 155],
      [175, 170, 168, 162, 158, 153, 148, 142, 138, 132, 128],
      [205, 198, 190, 182, 175, 168, 162, 155, 150, 145, 140],
    ];

    setChartData({
      temperature: temperatureSets[index] || temperatureSets[0],
      salinity: salinitySets[index] || salinitySets[0],
    });
  };

  // =========================================================
  // PARAMETER CLICK
  // =========================================================

  const handleParameterClick = (parameter) => {
    if (parameter === "temperature") {
      runQuery("Temperature near India");
      return;
    }

    if (parameter === "salinity") {
      runQuery("Salinity in Arabian Sea");
      return;
    }

    if (parameter === "pressure / depth") {
      runQuery("Show deeper measurements");
      return;
    }

    if (parameter === "float locations") {
      runQuery("Where are the floats?");
    }
  };

  // =========================================================
  // MAP SCROLL
  // =========================================================

  const scrollToMap = () => {
    const map = document.querySelector(".map-container");

    if (map) {
      map.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });

      // Small visual interaction after scrolling.
      map.classList.remove("map-focus");

      setTimeout(() => {
        map.classList.add("map-focus");

        setTimeout(() => {
          map.classList.remove("map-focus");
        }, 900);
      }, 500);
    }
  };

  // =========================================================
  // VIEW DATA DETAILS
  // =========================================================

  const toggleDataDetails = () => {
    setDetailsOpen((previous) => !previous);
  };

  // =========================================================
  // CLEAR SELECTED FLOAT
  // =========================================================

  const clearSelectedFloat = () => {
    setSelectedFloat(null);
  };

  // =========================================================
  // RENDER
  // =========================================================

  return (
    <div
      className={`app ${
        darkMode ? "dark-mode" : "light-mode"
      }`}
    >
      {/* =====================================================
          HEADER
      ===================================================== */}

      <header className="navbar">
        <div className="nav-inner">

          <div className="brand">

            <div className="brand-logo">
              🌊
            </div>

            <div className="brand-copy">

              <div className="brand-name">
                ARGO <span>AI</span>
              </div>

              <div className="brand-tagline">
                Conversational Interface for Exploring Ocean Data
              </div>

            </div>

          </div>

          <nav className="nav-links">

            <a
              className="active"
              href="#home"
            >
              Home
            </a>

            <a href="#about">
              About
            </a>

            <a href="#features">
              Features
            </a>

            <a href="#data">
              Data
            </a>

          </nav>

          <button
            className="theme-button"
            aria-label="Change theme"
            onClick={() =>
              setDarkMode((previous) => !previous)
            }
          >
            {darkMode ? "☼" : "☾"}
          </button>

        </div>
      </header>

      {/* =====================================================
          MAIN
      ===================================================== */}

      <main>

        {/* ===================================================
            HERO
        =================================================== */}

        <section
          className="hero"
          id="home"
        >

          <div className="hero-background-grid" />

          <div className="hero-inner">

            <div className="hero-content">

              <div className="eyebrow">

                <span className="status-dot" />

                REAL ARGO DATA

                <span>•</span>

                AI POWERED

                <span>•</span>

                INTERACTIVE VISUALIZATIONS

              </div>

              <h1>
                Explore the Ocean
                <br />
                with <span>AI</span>
              </h1>

              <p className="hero-description">
                Ask questions about real ARGO ocean data and get
                instant insights with charts, maps and detailed
                observations.
              </p>

              {/* SEARCH */}

              <div className="search-area">

                <form
                  className="search-box"
                  onSubmit={handleSubmit}
                >

                  <span className="search-icon">
                    ⌕
                  </span>

                  <input
                    type="text"
                    value={query}
                    onChange={(event) =>
                      setQuery(event.target.value)
                    }
                    placeholder='Try asking... "Show temperature near India"'
                    aria-label="Ask about ARGO ocean data"
                  />

                  <button
                    type="submit"
                    disabled={loading}
                  >
                    {loading ? (
                      <span className="button-loader" />
                    ) : (
                      "Ask →"
                    )}
                  </button>

                </form>

                {error && (
                  <div className="search-error">
                    ⚠ {error}
                  </div>
                )}

                <div className="popular">

                  <span className="popular-label">
                    Popular questions:
                  </span>

                  <div className="question-list">

                    {questions.map((question) => (
                      <button
                        key={question}
                        type="button"
                        onClick={() =>
                          handleQuestionClick(question)
                        }
                      >
                        {question}
                      </button>
                    ))}

                  </div>

                </div>

              </div>

            </div>

            {/* =================================================
                EARTH
            ================================================= */}

            <div className="hero-visual">

              <div className="orbit orbit-one" />

              <div className="orbit orbit-two" />

              <div className="glow" />

              <RealisticEarth />

              <div className="floating-dot dot-one" />
              <div className="floating-dot dot-two" />
              <div className="floating-dot dot-three" />
              <div className="floating-dot dot-four" />

              <div className="stats-card">

                <div className="stat">

                  <div className="stat-heading">
                    <span className="green-dot" />
                    ARGO FLOATS
                  </div>

                  <strong>
                    3,984
                  </strong>

                  <small>
                    Active observations
                  </small>

                </div>

                <div className="stat-divider" />

                <div className="stat">

                  <div className="stat-heading">
                    <span className="coral-dot" />
                    RECENT DATA
                  </div>

                  <strong>
                    {oceanData.observations}
                  </strong>

                  <small>
                    Measurements
                  </small>

                </div>

              </div>

              <div className="visual-caption">

                <span />

                <div>
                  REAL-TIME GLOBAL OCEAN

                  <strong>
                    INTELLIGENCE
                  </strong>
                </div>

              </div>

            </div>

          </div>

        </section>

        {/* ===================================================
            DASHBOARD
        =================================================== */}

        <section
          className="dashboard"
          id="features"
        >

          <div className="dashboard-inner">

            {/* =================================================
                AI RESPONSE
            ================================================= */}

            <div className="ai-response">

              <div className="ai-icon">
                🤖
              </div>

              <div className="ai-copy">

                <div className="response-title-row">

                  <h2>
                    {loading
                      ? "Analyzing..."
                      : response.title}
                  </h2>

                  {!loading && activeQuery && (
                    <span className="response-status">
                      ● Live
                    </span>
                  )}

                </div>

                <p>
                  {loading
                    ? "Analyzing your ocean-data question..."
                    : response.text}
                </p>

                {activeQuery && !loading && (
                  <small className="active-query">
                    Current query: "{activeQuery}"
                  </small>
                )}

              </div>

              {loading ? (
                <div className="ai-loading">
                  <span />
                  <span />
                  <span />
                </div>
              ) : (
                <div className="wave">
                  ∿∿∿
                </div>
              )}

            </div>

            {/* =================================================
                CONVERSATION CONTEXT
            ================================================= */}

            {conversation.length > 0 && (
              <div className="conversation-panel">

                <div className="conversation-heading">

                  <span>
                    💬
                  </span>

                  <div>

                    <strong>
                      Conversation context
                    </strong>

                    <small>
                      Your recent ocean questions
                    </small>

                  </div>

                </div>

                <div className="conversation-list">

                  {conversation.map(
                    (item, index) => (
                      <button
                        key={`${item}-${index}`}
                        type="button"
                        onClick={() => runQuery(item)}
                      >
                        {item}
                      </button>
                    )
                  )}

                </div>

                <div className="follow-up">

                  <span>
                    Continue exploring:
                  </span>

                  <div>

                    {followUpQuestions.map(
                      (question) => (
                        <button
                          key={question}
                          type="button"
                          onClick={() =>
                            handleFollowUp(question)
                          }
                        >
                          {question} →
                        </button>
                      )
                    )}

                  </div>

                </div>

              </div>
            )}

            {/* =================================================
                CARDS
            ================================================= */}

            <div className="cards-grid">

              {/* =================================================
                  OCEAN DATA CARD
              ================================================= */}

              <article
                className="data-card"
                id="data"
              >

                <div className="card-header">

                  <div className="card-icon coral-icon">
                    ▥
                  </div>

                  <div>

                    <h2>
                      Ocean Data
                    </h2>

                    <p>
                      Temperature & salinity observations
                    </p>

                  </div>

                </div>

                {/* CHART */}

                <div className="chart-container">

                  <div className="chart-grid" />

                  <svg
                    className="chart"
                    viewBox="0 0 600 260"
                    preserveAspectRatio="none"
                  >

                    <polyline
                      points={chartData.temperature
                        .map(
                          (value, index) =>
                            `${index * 60},${value}`
                        )
                        .join(" ")}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="4"
                      className="chart-line-green"
                    />

                    <polyline
                      points={chartData.salinity
                        .map(
                          (value, index) =>
                            `${index * 60},${value}`
                        )
                        .join(" ")}
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="4"
                      className="chart-line-coral"
                    />

                  </svg>

                  <div className="chart-legend">

                    <div>

                      <span className="legend-green" />

                      Temperature

                      <strong>
                        {oceanData.temperature}
                      </strong>

                    </div>

                    <div>

                      <span className="legend-coral" />

                      Salinity

                      <strong>
                        {oceanData.salinity}
                      </strong>

                    </div>

                    <div>

                      <span className="legend-purple" />

                      Depth

                      <strong>
                        {oceanData.depth}
                      </strong>

                    </div>

                  </div>

                </div>

                {/* OBSERVATION STATS */}

                <div className="observation-stats">

                  <div>

                    <span>
                      OBSERVATIONS
                    </span>

                    <strong>
                      {oceanData.observations}
                    </strong>

                  </div>

                  <div>

                    <span>
                      DATE RANGE
                    </span>

                    <strong>
                      {oceanData.dateRange}
                    </strong>

                  </div>

                </div>

                {/* DATA DETAILS BUTTON */}

                <button
                  className="card-action"
                  type="button"
                  onClick={toggleDataDetails}
                >
                  {detailsOpen
                    ? "Hide Data Details ↑"
                    : "View Data Details →"}
                </button>

                {/* DATA DETAILS */}

                {detailsOpen && (
                  <div className="data-details">

                    <div className="detail-row">

                      <span>
                        Temperature
                      </span>

                      <strong>
                        {oceanData.temperature}
                      </strong>

                    </div>

                    <div className="detail-row">

                      <span>
                        Salinity
                      </span>

                      <strong>
                        {oceanData.salinity}
                      </strong>

                    </div>

                    <div className="detail-row">

                      <span>
                        Depth
                      </span>

                      <strong>
                        {oceanData.depth}
                      </strong>

                    </div>

                    <div className="detail-row">

                      <span>
                        Observations
                      </span>

                      <strong>
                        {oceanData.observations}
                      </strong>

                    </div>

                    <div className="detail-row">

                      <span>
                        Date range
                      </span>

                      <strong>
                        {oceanData.dateRange}
                      </strong>

                    </div>

                  </div>
                )}

              </article>

              {/* =================================================
                  FLOAT MAP CARD
              ================================================= */}

              <article className="data-card">

                <div className="card-header">

                  <div className="card-icon green-icon">
                    ✧
                  </div>

                  <div>

                    <h2>
                      ARGO Float Locations
                    </h2>

                    <p>
                      Select a float to inspect observations
                    </p>

                  </div>

                </div>

                <div className="map-container">

                  <div className="map-grid" />

                  <div className="map-earth">
                    🌍
                  </div>

                  {/* FLOAT MARKERS */}

                  <button
                    className={`map-point p1 ${
                      selectedFloat?.id === "ARGO-2901"
                        ? "selected"
                        : ""
                    }`}
                    type="button"
                    aria-label="ARGO-2901"
                    title="ARGO-2901 — Arabian Sea"
                    onClick={() =>
                      handleFloatClick(floats[0])
                    }
                  />

                  <button
                    className={`map-point p2 ${
                      selectedFloat?.id === "ARGO-1842"
                        ? "selected"
                        : ""
                    }`}
                    type="button"
                    aria-label="ARGO-1842"
                    title="ARGO-1842 — Bay of Bengal"
                    onClick={() =>
                      handleFloatClick(floats[1])
                    }
                  />

                  <button
                    className={`map-point p3 ${
                      selectedFloat?.id === "ARGO-3920"
                        ? "selected"
                        : ""
                    }`}
                    type="button"
                    aria-label="ARGO-3920"
                    title="ARGO-3920 — Indian Ocean"
                    onClick={() =>
                      handleFloatClick(floats[2])
                    }
                  />

                  <button
                    className={`map-point p4 ${
                      selectedFloat?.id === "ARGO-1175"
                        ? "selected"
                        : ""
                    }`}
                    type="button"
                    aria-label="ARGO-1175"
                    title="ARGO-1175 — Southern Indian Ocean"
                    onClick={() =>
                      handleFloatClick(floats[3])
                    }
                  />

                  <button
                    className={`map-point p5 ${
                      selectedFloat?.id === "ARGO-4218"
                        ? "selected"
                        : ""
                    }`}
                    type="button"
                    aria-label="ARGO-4218"
                    title="ARGO-4218 — Western Pacific"
                    onClick={() =>
                      handleFloatClick(floats[4])
                    }
                  />

                  <div className="map-legend">

                    <div>
                      <span className="green-dot" />
                      Active
                    </div>

                    <div>
                      <span className="coral-dot" />
                      Inactive
                    </div>

                    <div>
                      <span className="cyan-dot" />
                      Recent
                    </div>

                  </div>

                </div>

                {/* SELECTED FLOAT */}

                {selectedFloat && (
                  <div className="float-details">

                    <div className="float-details-top">

                      <div>

                        <span>
                          SELECTED FLOAT
                        </span>

                        <strong>
                          {selectedFloat.id}
                        </strong>

                      </div>

                      <button
                        type="button"
                        aria-label="Close selected float"
                        onClick={clearSelectedFloat}
                      >
                        ×
                      </button>

                    </div>

                    <p>
                      📍 {selectedFloat.location}
                    </p>

                    <div className="float-grid">

                      <div>

                        <span>
                          POSITION
                        </span>

                        <strong>
                          {selectedFloat.latitude},{" "}
                          {selectedFloat.longitude}
                        </strong>

                      </div>

                      <div>

                        <span>
                          STATUS
                        </span>

                        <strong>
                          {selectedFloat.status}
                        </strong>

                      </div>

                      <div>

                        <span>
                          TEMPERATURE
                        </span>

                        <strong>
                          {selectedFloat.temperature}
                        </strong>

                      </div>

                      <div>

                        <span>
                          SALINITY
                        </span>

                        <strong>
                          {selectedFloat.salinity}
                        </strong>

                      </div>

                    </div>

                    <div className="detail-row">
                      <span>
                        Last observation
                      </span>

                      <strong>
                        {selectedFloat.lastObservation}
                      </strong>
                    </div>

                    <div className="detail-row">
                      <span>
                        Depth
                      </span>

                      <strong>
                        {selectedFloat.depth}
                      </strong>
                    </div>

                  </div>
                )}

                {/* EXPLORE MAP */}

                <button
                  className="card-action"
                  type="button"
                  onClick={scrollToMap}
                >
                  Explore Map →
                </button>

              </article>

              {/* =================================================
                  PARAMETERS
              ================================================= */}

              <article className="data-card parameters-card">

                <div className="card-header">

                  <div className="card-icon green-icon">
                    ≋
                  </div>

                  <div>

                    <h2>
                      Key Ocean Parameters
                    </h2>

                    <p>
                      Explore what you can discover
                    </p>

                  </div>

                </div>

                <div className="parameter-grid">

                  {/* TEMPERATURE */}

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "temperature"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ◉
                    </div>

                    <div>

                      <h3>
                        Temperature
                      </h3>

                      <p>
                        Ocean heat & climate
                      </p>

                    </div>

                  </button>

                  {/* SALINITY */}

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "salinity"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ◌
                    </div>

                    <div>

                      <h3>
                        Salinity
                      </h3>

                      <p>
                        Water composition
                      </p>

                    </div>

                  </button>

                  {/* DEPTH */}

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "pressure / depth"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ≋
                    </div>

                    <div>

                      <h3>
                        Pressure / Depth
                      </h3>

                      <p>
                        Ocean structure
                      </p>

                    </div>

                  </button>

                  {/* FLOAT */}

                  <button
                    className="parameter"
                    type="button"
                    onClick={() =>
                      handleParameterClick(
                        "float locations"
                      )
                    }
                  >

                    <div className="parameter-icon">
                      ✧
                    </div>

                    <div>

                      <h3>
                        Float ID
                      </h3>

                      <p>
                        Track ARGO sensors
                      </p>

                    </div>

                  </button>

                </div>

                {/* LEARN MORE */}

                <button
                  className="card-action"
                  type="button"
                  onClick={() => {
                    document
                      .querySelector(
                        ".search-box input"
                      )
                      ?.focus();

                    document
                      .querySelector(
                        ".search-box"
                      )
                      ?.scrollIntoView({
                        behavior: "smooth",
                        block: "center",
                      });
                  }}
                >
                  Learn More →
                </button>

              </article>

            </div>

          </div>

        </section>

        {/* =====================================================
            FOOTER
        ===================================================== */}

        <footer id="about">

          <div className="footer-inner">

            <div className="footer-item">

              <div className="footer-icon">
                ◎
              </div>

              <div>

                <strong>
                  Global Coverage
                </strong>

                <span>
                  ARGO ocean observations
                </span>

              </div>

            </div>

            <div className="footer-item">

              <div className="footer-icon">
                □
              </div>

              <div>

                <strong>
                  Open Data
                </strong>

                <span>
                  ARGO data access
                </span>

              </div>

            </div>

            <div className="footer-item">

              <div className="footer-icon coral-text">
                ϟ
              </div>

              <div>

                <strong>
                  AI Powered
                </strong>

                <span>
                  Natural language queries
                </span>

              </div>

            </div>

            <div className="footer-message">

              Better data. Better decisions.

              <span>
                Explore our ocean.
              </span>

            </div>

          </div>

        </footer>

      </main>
    </div>
  );
}

export default App;                                               